# Study Sphere — starter app

This is a phone-friendly educational web app prototype for JKBOSE Classes 9 and 10.

## Included
- Home dashboard
- Digital library with sample resource entries
- Starter revision notes
- Subject-wise sample MCQ quizzes with scoring and explanations
- Practice-paper outlines (not official past papers)
- Search
- Responsive mobile layout
- Basic PWA manifest and offline cache support when served over HTTPS

## How to try it on Android
1. Extract the ZIP file.
2. Open `index.html` in a browser to preview the interface (some install/offline features require hosting over HTTPS).
3. To make it installable as a web app, upload the files to a static HTTPS host such as GitHub Pages or Netlify, then open the published URL in Chrome and choose **Add to Home screen** / **Install app**.
4. The Android APK is not included. A packaged APK requires an additional build process.

## Important
- Sample questions and notes are starter content, not a complete syllabus or official JKBOSE material.
- Verify the current JKBOSE syllabus and use authorised, accurate study resources before publishing.
- This starter app does not yet include accounts, cloud syncing, or an admin panel to upload content.
